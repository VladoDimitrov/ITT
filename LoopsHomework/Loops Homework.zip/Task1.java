package LoopsHomework;

public class Task1 {

	public static void main(String[] args) {

		for (int num = 1; num <= 100; num++) {
			System.out.println(num);
		}

	}

}
