package LoopsHomework;

public class Task2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int num = -20; num <= 50; num++) {
			System.out.println(num);
		}
	}

}
