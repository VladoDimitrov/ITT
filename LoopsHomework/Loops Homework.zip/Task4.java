package LoopsHomework;

public class Task4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int num = 10; num >= 1; num--) {
			System.out.println(num);
		}
	}

}
